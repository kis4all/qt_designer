from youtube_transcript_api import YouTubeTranscriptApi
import re

def get_auto_generated_captions(video_url):
    try:
        video_id = video_url.split("v=")[1]  # Extract video ID from the URL
        captions = YouTubeTranscriptApi.get_transcript(video_id, languages=['en'])
        return captions
    except Exception as e:
        print(f"An error occurred: {str(e)}")
        return None

def remove_timestamps(text):
    # Use regular expression to remove timestamps
    return re.sub(r'\[\d+:\d+\]', '', text)

def save_captions_to_file(captions, filename='captions.txt'):
    if captions:
        with open(filename, 'w', encoding='utf-8') as file:
            for caption in captions:
                cleaned_text = remove_timestamps(caption['text'])
                file.write(f"{cleaned_text}\n")
        print(f"Captions (without timestamps) saved to {filename}")
    else:
        print("Auto-generated captions not available.")

# YouTube Video URL
video_url = "https://www.youtube.com/watch?v=jhcoG-PHot8"

# Get auto-generated captions
captions = get_auto_generated_captions(video_url)

# Save captions without timestamps to a file
save_captions_to_file(captions, filename='captions_without_timestamps.txt')
